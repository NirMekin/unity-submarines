﻿using UnityEngine;
using System.Collections;

public class DefinedVariables
{
    public enum MenuScreens
    {
        Default, Main, SinglePlayer, Multiplayer, StudentInfo, Options, Loading
    };

}
